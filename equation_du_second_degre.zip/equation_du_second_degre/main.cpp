#include <iostream>
#include<string>
#include<math.h>
using namespace std;

int main()
{
    double a,b,c;
    double x1,x2,n,r;
    string reponse;
           do
    {
       cout<<"Votre equation doit etre de la forme ax^2 + bx +c =0"<<endl;
       cout<<"Donner a"<<endl;
       cin>>a;
       cout<<"Donner b"<<endl;
       cin>>b;
       cout<<"Donner c"<<endl;
       cin>>c;
       cout<<a<<"x^2 + "<<b<<"x + "<<c<<"=0"<<endl;
       if(a==0)
     {
        cout<<"Votre equation n'est pas du second degre"<<endl;
          if(b==0)
         {
              if(c==0)
              {
                  cout<<"l'ensemble solution est C"<<endl;
              }else{
                  cout<<" Pas de solution dans C car "<<c<<" different de 0"<<endl;
              }
         }else{
              double x;
              x=((-c)/b);
              cout<<"La solution dans R est : "<<x<<endl;
          }
     }
        else
       {
            double delta;
            delta=(b*b)-(4*a*c);
            cout<<"Le discriminant de votre fonction est:"<<delta<<endl;
            if(delta<0)
            {
                n= sqrt(-delta);
            double x1r,x2i;
            x1r=(-b/(2*a));
            x2i=(n/(2*a));
            cout<<"l'equation admet deux solutions complexes :"<<x1r<<" - "<<x2i<<"i et "<<x1r<<" + "<<x2i<<"i"<<endl;
            }else
             {
                if(delta==0)
                {
                   x1=(-b/(2*a));
                     cout<<"L'equation admet une soltion double qui est: "<<x1<<endl;
                 }else
                     {
                    r=sqrt(delta);
                    x1=((-b-r)/(2*a));
                    x2=((-b+r)/(2*a));
                    cout<<" Votre equation a deux solutions distinctes qui sont"<<x1<<" et "<<x2<<endl;
                 }
            }
        }
    cout<<" Voulez vous resoudre une autre equation ? entrer oui ou non. "<<endl;
    cin>>reponse;
    }while (reponse=="oui" || reponse=="Oui"|| reponse=="OUI" );
     return 0 ;
}
